﻿using EventEaseApp.Models;
using Microsoft.EntityFrameworkCore;

namespace EventEaseApp.Data
{
    public class EventEaseContext
    {
        public EventEaseContext(DbContextOptions<EventEaseContext> options) : base(options) { }

        public DbSet<Venue> Venues { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<Booking> Bookings { get; set; }
    }
}
