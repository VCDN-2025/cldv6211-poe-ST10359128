﻿namespace EventEaseApp.Models
    //model class for events
{
    public class Event
    {
        public int EventID { get; set; }
        public string Name { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Description { get; set; }

        public ICollection<Booking> Bookings { get; set; }
        public int? EventTypeID { get; set; }
        public EventType EventType { get; set; }

    }
}
