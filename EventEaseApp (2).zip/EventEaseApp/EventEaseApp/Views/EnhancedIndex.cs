﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using static AspNetCoreGeneratedDocument.Views_BookingDisplay;

namespace EventEaseApp.Views
{
    public class EnhancedIndex
    {
        public async Task<IActionResult> EnhancedIndex(string search, int? eventTypeID, bool? isAvailable, DateTime? fromDate, DateTime? toDate)
        {
            var query = from b in _context.Bookings
                        join e in _context.Events on b.EventID equals e.EventID
                        join v in _context.Venues on b.VenueID equals v.VenueID
                        join t in _context.EventTypes on e.EventTypeID equals t.EventTypeID into et
                        from t in et.DefaultIfEmpty()
                        select new BookingDisplayViewModel
                        {
                            BookingID = b.BookingID,
                            EventName = e.Name,
                            VenueName = v.Name,
                            Location = v.Location,
                            StartDate = b.StartDate,
                            EndDate = b.EndDate,
                            Status = b.Status,
                            EventType = t.TypeName,
                            IsAvailable = v.IsAvailable
                        };

            if (!string.IsNullOrEmpty(search))
                query = query.Where(b => b.EventName.Contains(search) || b.BookingID.ToString().Contains(search));

            if (eventTypeID.HasValue)
                query = query.Where(b => b.EventTypeID == eventTypeID.Value);

            if (isAvailable.HasValue)
                query = query.Where(b => b.IsAvailable == isAvailable.Value);

            if (fromDate.HasValue)
                query = query.Where(b => b.StartDate >= fromDate.Value);

            if (toDate.HasValue)
                query = query.Where(b => b.EndDate <= toDate.Value);

            return View(await query.ToListAsync());
        }



    }
}
